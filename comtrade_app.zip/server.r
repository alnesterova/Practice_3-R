library('shiny')       # загрузка пакетов
library('dplyr')
library('data.table')
library('RCurl')

# загрузка данных
fileURL <- 'https://raw.githubusercontent.com/alnesterova/Practice_3-R/main/comtrade/Comtrade_DT_updated.csv'
# создаём директорию для данных, если она не существует:
if (!file.exists('./data')) dir.create('./data')
# загружаем файл, если он не существует
if (!file.exists('./data/Comtrade_DT_updated.csv')) {
  download.file(fileURL, './data/Comtrade_DT_updated.csv')}
# читаем данные из загруженного .csv во фрейм
DT <- data.table(read.csv('./data/Comtrade_DT_updated.csv', as.is = T))

shinyServer(function(input, output){
  DT <- reactive({
    DT <- data[between(Year, input$year.range[1], input$year.range[2]) & 
                 Commodity.Code == input$sp.to.plot & Trade.Flow == input$trade.to.plot, ]
    DT <- data.table(DT) 
  })
  output$sp.ggplot <- renderPlot({
    ggplot(data = DT(), aes(x = Trade.Value.USD, y =  Netweight.kg.mean)) + geom_point() +
      geom_hline(aes(yintercept = median(Netweight.kg.mean)), color = "red") +
      xlab('Масса поставки, кг') + ylab('Стоимость, USD')
  })
})
